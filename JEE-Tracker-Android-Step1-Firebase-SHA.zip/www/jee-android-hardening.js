/* JEE Tracker — Stage 5 Android hardening
 * Lifecycle-safe, permission-safe glue for Capacitor Android.
 * Does not change the existing tracker data model or UI.
 */
(function () {
  'use strict';
  const native = !!(window.Capacitor?.isNativePlatform?.());
  if (!native) return;

  const App = window.Capacitor?.Plugins?.App;
  const FS = window.Capacitor?.Plugins?.Filesystem;

  function flush() {
    try { window.dispatchEvent(new CustomEvent('jee-native-flush-request')); } catch (_) {}
    try { window.JEEFileStore?.flush?.(); } catch (_) {}
  }

  if (App) {
    App.addListener('appStateChange', ({ isActive }) => {
      if (!isActive) {
        flush();
        return;
      }
      // Let existing pages refresh their state after Android resumes the WebView.
      window.dispatchEvent(new CustomEvent('jee-app-resumed'));
      window.dispatchEvent(new Event('storage'));
    });

    App.addListener('appRestoredResult', result => {
      window.dispatchEvent(new CustomEvent('jee-app-restored-result', { detail: result || {} }));
    });
  }

  // App-private DATA storage does not require READ/WRITE_EXTERNAL_STORAGE.
  // We deliberately do not request broad external-storage permissions.
  if (FS) {
    window.JEEAndroidStorage = {
      native: true,
      directory: 'DATA',
      permissionsRequired: false,
      async check() {
        try {
          const r = await FS.stat({ path: 'jee-tracker', directory: 'DATA' });
          return { ok: true, exists: true, uri: r.uri || null };
        } catch (_) {
          return { ok: true, exists: false, uri: null };
        }
      }
    };
  }

  document.addEventListener('visibilitychange', () => {
    if (document.visibilityState === 'hidden') flush();
  });
})();
