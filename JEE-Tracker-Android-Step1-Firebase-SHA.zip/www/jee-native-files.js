/* JEE Tracker — Stage 4 native document vault
 * Keeps the existing File objects and PDF.js/OCR pipeline unchanged while
 * making selected analysis files durable inside Android app-private storage.
 */
(function(){
  'use strict';
  const ROOT='jee-tracker/uploads-v1';
  const INDEX='jee-tracker/uploads-v1/index.json';
  const VERSION=2;
  const MAX_FILE_BYTES=50*1024*1024;
  let fs=null;
  try{fs=window.Capacitor?.Plugins?.Filesystem||null}catch(_){fs=null}
  const native=()=>!!(window.Capacitor?.isNativePlatform?.()&&fs);
  const safe=(s)=>String(s||'file').replace(/[^a-zA-Z0-9._-]+/g,'_').slice(0,120);
  async function readIndex(){
    if(!native())return [];
    try{const r=await fs.readFile({path:INDEX,directory:'DATA',encoding:'utf8'});const x=JSON.parse(r.data||'[]');return Array.isArray(x)?x:[]}catch(_){return []}
  }
  async function writeIndex(x){if(!native())return;await fs.writeFile({path:INDEX,directory:'DATA',data:JSON.stringify(x.slice(0,100)),encoding:'utf8',recursive:true})}
  function ab64(buf){let bin='';const bytes=new Uint8Array(buf);const step=0x8000;for(let i=0;i<bytes.length;i+=step)bin+=String.fromCharCode(...bytes.subarray(i,i+step));return btoa(bin)}
  async function saveFile(file){
    if(!native()||!file)return null;
    if(Number(file.size||0)>MAX_FILE_BYTES) throw new Error('File exceeds the 50 MB Android app limit.');
    const id='u_'+Date.now().toString(36)+'_'+Math.random().toString(36).slice(2,8);
    const name=safe(file.name||'upload');
    const path=ROOT+'/'+id+'_'+name;
    const buffer=await file.arrayBuffer();
    const data=ab64(buffer);
    await fs.writeFile({path,directory:'DATA',data,recursive:true});
    let sha256=null;
    try { const digest=await crypto.subtle.digest('SHA-256',buffer); sha256=Array.from(new Uint8Array(digest)).map(x=>x.toString(16).padStart(2,'0')).join(''); } catch(_) {}
    const rec={version:VERSION,id,name:file.name||name,type:file.type||'application/octet-stream',size:file.size||0,path,sha256,createdAt:new Date().toISOString()};
    const idx=await readIndex();idx.unshift(rec);await writeIndex(idx);return rec;
  }
  async function saveFiles(files,onProgress){
    if(!native())return [];
    const arr=Array.from(files||[]),out=[];
    for(let i=0;i<arr.length;i++){try{const r=await saveFile(arr[i]);if(r)out.push(r)}catch(e){console.warn('[JEE] Native upload save failed',arr[i]?.name,e)}if(onProgress)onProgress(i+1,arr.length)}
    return out;
  }
  async function list(){return readIndex()}
  async function remove(id){if(!native())return false;const idx=await readIndex(),r=idx.find(x=>x.id===id);if(!r)return false;try{await fs.deleteFile({path:r.path,directory:'DATA'})}catch(_){}await writeIndex(idx.filter(x=>x.id!==id));return true}
  async function flush(){ return true; }
  async function clear(){if(!native())return;const idx=await readIndex();for(const r of idx){try{await fs.deleteFile({path:r.path,directory:'DATA'})}catch(_){} }await writeIndex([])}
  window.JEEFileStore={version:VERSION,isNative:native,saveFile,saveFiles,list,remove,clear,flush,root:ROOT,maxFileBytes:MAX_FILE_BYTES};
  window.dispatchEvent(new CustomEvent('jee-native-file-store-ready',{detail:{version:VERSION,native:native()}}));
})();
