/* JEE Tracker Android bridge — Stage 2
 * Safe in both a normal browser/PWA and a Capacitor WebView.
 * Does not replace or rewrite the existing application logic.
 */
(function () {
  'use strict';

  const isCapacitor = !!(window.Capacitor && window.Capacitor.isNativePlatform && window.Capacitor.isNativePlatform());
  if (!isCapacitor) return;

  const App = window.Capacitor?.Plugins?.App;
  if (!App) return;

  function currentFile() {
    const p = (location.pathname || '').split('/').pop();
    return p || 'index.html';
  }

  function goToHub() {
    if (currentFile() !== 'index.html') {
      location.href = 'index.html';
      return true;
    }
    return false;
  }

  // Android system back: move from secondary pages back to Main Hub first.
  App.addListener('backButton', ({ canGoBack }) => {
    if (goToHub()) return;
    if (canGoBack && history.length > 1) {
      history.back();
      return;
    }
    App.exitApp();
  });

  // Keep the app responsive after returning from background.
  App.addListener('appStateChange', ({ isActive }) => {
    if (!isActive) return;
    window.dispatchEvent(new CustomEvent('jee-app-resumed'));
    window.dispatchEvent(new Event('storage'));
  });

  // Android deep-link / intent URLs: preserve the existing page routing model.
  App.addListener('appUrlOpen', ({ url }) => {
    try {
      const target = new URL(url);
      const page = target.searchParams.get('page');
      if (page === 'schedule') location.href = 'schedule.html';
      else if (page === 'test-analysis') location.href = 'test-analysis.html';
    } catch (_) {}
  });
})();
