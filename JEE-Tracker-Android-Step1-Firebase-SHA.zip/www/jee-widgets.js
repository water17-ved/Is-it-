/* JEE Tracker Android home-screen widgets bridge. No API key or network required. */
(function(){
  const K={q:'jee-daily-questions',hours:'jee-study-hours',targets:'jee-daily-targets',tp:'jee-target-progress',schedule:'jee-daily-schedule',streak:'jee-streak',tests:'jee-test-analysis-history',pdf:'jee-pdf-analysis-history'};
  const get=(k,d)=>{try{const v=localStorage.getItem(k);return v==null?d:JSON.parse(v)}catch{return d}};
  const today=()=>{const d=new Date();return `${d.getFullYear()}-${String(d.getMonth()+1).padStart(2,'0')}-${String(d.getDate()).padStart(2,'0')}`};
  const fmtH=n=>{n=Number(n)||0;const h=Math.floor(n),m=Math.round((n-h)*60);return `${h}h ${String(m).padStart(2,'0')}m`};
  function state(){
    const t=today(), qs=Array.isArray(get(K.q,[]))?get(K.q,[]):[], hs=Array.isArray(get(K.hours,[]))?get(K.hours,[]):[], sched=Array.isArray(get(K.schedule,[]))?get(K.schedule,[]):[];
    const tq=qs.filter(x=>x.date===t).reduce((n,x)=>n+(Number(x.count)||0),0);
    const sh=hs.find(x=>x.date===t)||{}; const hours=(Number(sh.physicsHours)||0)+(Number(sh.chemistryHours)||0)+(Number(sh.mathsHours)||0);
    const blocks=sched.filter(x=>!x.date||x.date===t).sort((a,b)=>String(a.time||'').localeCompare(String(b.time||'')));
    const done=blocks.filter(x=>x.completed).length, total=blocks.length;
    const next=blocks.find(x=>!x.completed)?.label||blocks.find(x=>!x.completed)?.title||'No mission scheduled';
    const targetList=Array.isArray(get(K.targets,[]))?get(K.targets,[]):[], prog=get(K.tp,{})[t]||{};
    let target=0, targetDone=0;
    targetList.forEach(x=>{if(x.type==='counter'){target+=Number(x.targetValue)||0;targetDone+=Math.min(Number(x.targetValue)||0,Number(prog[x.id])||0)}else{target+=1;if(prog[x.id])targetDone++}});
    const p=target?Math.round(targetDone/target*100):(total?Math.round(done/total*100):0);
    const streak=get(K.streak,{})||{};
    let scoreTitle='LATEST TEST',score='—',scoreMeta='Analyse a test to see your score',accuracy='—',rank='—';
    const arr=[...(Array.isArray(get(K.tests,[]))?get(K.tests,[]):[]),...(Array.isArray(get(K.pdf,[]))?get(K.pdf,[]):[])].sort((a,b)=>String(b.date||b.importedAt||'').localeCompare(String(a.date||a.importedAt||'')));
    if(arr[0]){const r=arr[0],s=r.totalScore||r.score||{};const my=s.my??r.marks??r.score??null,max=s.max??r.maxScore??null;score=my!=null?(max!=null?`${my}/${max}`:String(my)):'—';scoreTitle=r.testName||r.fileName||'LATEST TEST';scoreMeta=r.date||r.importedAt?.slice(0,10)||'Latest analysis';accuracy=(r.overall?.accuracy!=null?`${r.overall.accuracy}%`:'—');rank=r.rank!=null?String(r.rank):r.percentile!=null?`${r.percentile}%ile`:'—'}
    return {date:new Date().toLocaleDateString(undefined,{weekday:'short',day:'numeric',month:'short'}),title:total?`${done}/${total} MISSIONS COMPLETE`:(target?`${targetDone}/${target} TARGET`:'TODAY\'S MISSION'),questions:`${tq} / ${target||'—'}`,hours:fmtH(hours),streak:`${Number(streak.currentStreak)||0} day streak`,next:next,progress:p,scoreTitle,score,scoreMeta,accuracy,rank,nextSub:blocks.find(x=>!x.completed)?.time?`Next at ${blocks.find(x=>!x.completed).time}`:'Tap to open Mission Centre'};
  }
  async function push(){try{const plugin=window.Capacitor?.Plugins?.JEEWidgets;if(!plugin?.update)return;await plugin.update({state:state()});}catch(e){/* Widgets are optional on non-Android/web builds. */}}
  window.JEEWidgets={refresh:push};
  const boot=()=>{push();setTimeout(push,900);setTimeout(push,3000)};
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',boot,{once:true});else boot();
  window.addEventListener('storage',()=>push());
  try{const bc=('BroadcastChannel' in window)?new BroadcastChannel('jee-tracker-sync-v1'):null;bc?.addEventListener('message',()=>push())}catch{}
  setInterval(push,60000);
})();
