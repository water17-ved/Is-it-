/* JEE Tracker Stage 7 — network state only. No user data is stored here. */
(function(){
  'use strict';
  const id='jee-network-status';
  function state(){ return navigator.onLine ? 'online' : 'offline'; }
  function render(){
    let el=document.getElementById(id);
    if(!el){
      el=document.createElement('div'); el.id=id;
      el.setAttribute('role','status'); el.setAttribute('aria-live','polite');
      el.style.cssText='position:fixed;left:50%;top:8px;transform:translateX(-50%);z-index:2147483647;padding:7px 12px;border-radius:999px;font:600 12px/1.2 system-ui,sans-serif;display:none;backdrop-filter:blur(8px);box-shadow:0 4px 16px rgba(0,0,0,.18);pointer-events:none;';
      document.body.appendChild(el);
    }
    const offline=state()==='offline';
    el.textContent=offline?'Offline — local tracker data still works':'Back online';
    el.style.display=(offline||el.dataset.justBack==='1')?'block':'none';
    el.style.background=offline?'rgba(120,35,35,.94)':'rgba(35,100,55,.94)';
    el.style.color='#fff';
    if(!offline){ el.dataset.justBack='1'; setTimeout(()=>{el.dataset.justBack='0';el.style.display='none'},2200); }
  }
  window.JEENetwork={isOnline:()=>state()==='online',state,refresh:render};
  window.addEventListener('online',render); window.addEventListener('offline',render);
  if(document.readyState==='loading') document.addEventListener('DOMContentLoaded',render,{once:true}); else render();
})();
