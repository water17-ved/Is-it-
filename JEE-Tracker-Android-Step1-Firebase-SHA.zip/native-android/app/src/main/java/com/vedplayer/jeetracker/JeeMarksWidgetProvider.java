package com.vedplayer.jeetracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class JeeMarksWidgetProvider extends AppWidgetProvider {
    private static final int FLAG = PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT >= 23 ? PendingIntent.FLAG_IMMUTABLE : 0);
    @Override public void onUpdate(Context c, AppWidgetManager m, int[] ids) { for (int id: ids) update(c,m,id); }
    @Override public void onReceive(Context c, Intent i) { super.onReceive(c,i); if (JeeWidgetsPlugin.ACTION_UPDATE.equals(i.getAction())) { AppWidgetManager m=AppWidgetManager.getInstance(c); int[] ids=m.getAppWidgetIds(new android.content.ComponentName(c,JeeMarksWidgetProvider.class)); for(int id:ids)update(c,m,id); } }
    private void update(Context c, AppWidgetManager m, int id) {
        JSONObject s; try{s=new JSONObject(JeeWidgetsPlugin.getState(c));}catch(Exception e){s=new JSONObject();}
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_jee_marks);
        v.setTextViewText(R.id.m_title,s.optString("scoreTitle","LATEST TEST"));
        v.setTextViewText(R.id.m_score,s.optString("score","—"));
        v.setTextViewText(R.id.m_meta,s.optString("scoreMeta","Analyse a test to see your score"));
        v.setTextViewText(R.id.m_accuracy,s.optString("accuracy","—"));
        v.setTextViewText(R.id.m_rank,s.optString("rank","—"));
        Intent launch=new Intent(c,MainActivity.class).putExtra("jee_page","test-analysis");
        v.setOnClickPendingIntent(R.id.m_root,PendingIntent.getActivity(c,id,launch,FLAG));
        m.updateAppWidget(id,v);
    }
}
