package com.vedplayer.jeetracker;

import android.app.PendingIntent;
import android.appwidget.AppWidgetManager;
import android.appwidget.AppWidgetProvider;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.widget.RemoteViews;
import org.json.JSONObject;

public class JeeFocusWidgetProvider extends AppWidgetProvider {
    private static final int FLAG=PendingIntent.FLAG_UPDATE_CURRENT | (Build.VERSION.SDK_INT>=23?PendingIntent.FLAG_IMMUTABLE:0);
    @Override public void onUpdate(Context c,AppWidgetManager m,int[] ids){for(int id:ids)update(c,m,id);}
    @Override public void onReceive(Context c,Intent i){super.onReceive(c,i);if(JeeWidgetsPlugin.ACTION_UPDATE.equals(i.getAction())){AppWidgetManager m=AppWidgetManager.getInstance(c);int[] ids=m.getAppWidgetIds(new android.content.ComponentName(c,JeeFocusWidgetProvider.class));for(int id:ids)update(c,m,id);}}
    private void update(Context c,AppWidgetManager m,int id){
        JSONObject s;try{s=new JSONObject(JeeWidgetsPlugin.getState(c));}catch(Exception e){s=new JSONObject();}
        RemoteViews v=new RemoteViews(c.getPackageName(),R.layout.widget_jee_focus);
        v.setTextViewText(R.id.f_task,s.optString("next","Open Mission Centre"));
        v.setTextViewText(R.id.f_sub,s.optString("nextSub","Your next study block"));
        Intent launch=new Intent(c,MainActivity.class).putExtra("jee_page","schedule");
        v.setOnClickPendingIntent(R.id.f_root,PendingIntent.getActivity(c,id,launch,FLAG));
        m.updateAppWidget(id,v);
    }
}
