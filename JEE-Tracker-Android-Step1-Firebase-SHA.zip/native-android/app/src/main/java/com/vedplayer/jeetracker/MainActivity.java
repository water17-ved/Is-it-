package com.vedplayer.jeetracker;

import android.os.Bundle;
import android.os.Handler;
import android.content.Intent;
import com.getcapacitor.BridgeActivity;

public class MainActivity extends BridgeActivity {
    @Override public void onCreate(Bundle savedInstanceState) {
        registerPlugin(JeeWidgetsPlugin.class);
        super.onCreate(savedInstanceState);
        routeIfNeeded(getIntent());
    }
    @Override public void onNewIntent(Intent intent) {
        super.onNewIntent(intent);
        setIntent(intent);
        routeIfNeeded(intent);
    }
    private void routeIfNeeded(Intent intent) {
        String page=intent==null?null:intent.getStringExtra("jee_page");
        if(page==null)return;
        final String url=page.equals("test-analysis")?"test-analysis.html":"schedule.html";
        new Handler().postDelayed(() -> {
            if(getBridge()!=null && getBridge().getWebView()!=null)
                getBridge().getWebView().evaluateJavascript("window.location.href='"+url+"'",null);
        },500);
    }
}
