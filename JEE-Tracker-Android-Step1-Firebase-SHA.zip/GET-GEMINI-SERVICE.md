# Gemini service setup (Android)

## Important clarification
There is no official Google download called `Gemini service.js` that you obtain from Gemini API. For this app, the service layer is the JavaScript bridge that sends requests to the Gemini API. The API credential you obtain is a **Gemini API key**, not a `service.js` file.

## Recommended process
1. Open Google AI Studio and create/sign in to the Google account you want to use.
2. Create a Gemini API key from the API-key section.
3. Do **not** commit the API key to GitHub and do not put it in a public `service.js`.
4. In the app, open **Mission Schedule → AI Schedule Core** and paste the key into the device-only API key field, then Save Settings.
5. The app stores the key locally on the device. Gemini requests are sent only when an AI action is started.
6. For a production release, prefer a server-side proxy so the API key is never shipped to the client APK.

## If you specifically need a `gemini-service.js` file
Create it locally as a thin service module and keep the key outside source control. Example architecture:

```js
export async function generateGemini(prompt, apiKey, model='gemini-3.8-flash') {
  if (!apiKey) throw new Error('Gemini API key is missing.');
  const response = await fetch(
    `https://generativelanguage.googleapis.com/v1beta/models/${encodeURIComponent(model)}:generateContent?key=${encodeURIComponent(apiKey)}`,
    {
      method: 'POST',
      headers: {'Content-Type':'application/json'},
      body: JSON.stringify({contents:[{role:'user',parts:[{text:prompt}]}]})
    }
  );
  const data = await response.json();
  if (!response.ok) throw new Error(data?.error?.message || 'Gemini request failed.');
  return data?.candidates?.[0]?.content?.parts?.map(p=>p.text||'').join('') || '';
}
```

For this project, **do not add a hard-coded key to that file**. The existing app's AI configuration should supply the key at runtime.
