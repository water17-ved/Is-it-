# Stage 11 — Motion + Schedule Replacement

- Replaced the Android project's `www/schedule.html` with the newly attached `schedule-4.html`.
- Added a lightweight motion system to Main Hub, Test Analysis and Mission Schedule, tuned for Android WebView rather than heavy animation.
- Added press feedback, staged page entrance, smooth panel/card entrance, and a subtle AI-working scan indicator.
- Added `prefers-reduced-motion` handling.
- Added `GET-GEMINI-SERVICE.md` explaining the correct Gemini API-key/service-layer process and warning against committing secrets.
- Existing app data, AI, PDF/OCR, Firebase and native storage code were otherwise left intact.
