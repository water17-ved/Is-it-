# JEE Tracker Android — Stage 9

## Build/release preparation

This stage prepares the exact Stage 8 project for the first real Android APK build through GitHub Actions.

### Included
- Debug APK workflow using Node 22, Java 21 and Android SDK.
- Capacitor Android platform generated during CI from the checked-in web project.
- `npx cap sync android` so the current `www/` files and native plugins are included.
- APK SHA-256 checksum generation.
- APK + checksum uploaded as a GitHub Actions artifact.
- Manual `workflow_dispatch` trigger plus automatic builds on pushes to `main`.

### Verification performed in this environment
- Stage 8 archive extracted successfully.
- Required web pages and Android bridge files are present.
- Capacitor package/config files are present.
- Workflow YAML and build commands were reviewed.
- A local `npm install` attempt was made, but this environment could not complete the dependency download within the available execution window. Therefore no local APK build is claimed.

### What remains device/CI-dependent
1. Push this project to a GitHub repository.
2. Run **Actions → Build JEE Tracker Android APK → Run workflow**.
3. Download `jee-tracker-debug-apk`.
4. Install the APK on the Android phone.
5. Test navigation, persistence, PDF uploads, AI/network behavior, and all major tracker tabs.

No release signing key is embedded in this project. A production signed APK should be configured separately using GitHub encrypted secrets; never commit a keystore or signing password.
