# Stage 10 — Real-device issue fixes

## Fixed in source

- Android JSON backup export now uses native app storage + Android Share when running in Capacitor; browser download remains the fallback.
- Android JSON backup import uses the native system file picker and restores the complete localStorage snapshot plus legacy structured data.
- Android notifications now use Capacitor Local Notifications for persistent daily scheduling instead of relying on a JavaScript interval. Permission/channel handling and a test notification are included.
- Mission Centre schedule completion now writes structured activity into the Main Hub Daily Questions / Study Hours stores. Completion can be reversed without leaving duplicate entries. AI schedule blocks carry `questionCount` when the context supports it.
- Mission Centre AI context now includes Main Hub Daily Questions and Study Hours so generated schedules learn from the actual tracker history.
- Gemini analysis now treats multiple PDFs as separate evidence sources: Question Paper Analysis and Weakness/Performance Report are analysed independently, then reconciled. It no longer concatenates the PDFs and asks one prompt to guess which section came from which report.
- Gemini output now includes total score/max score and evidence-quality diagnostics, and score fields are merged into the final Battle Log record.
- A visible cross-page AI activity panel shows when Gemini is working, what it is doing, progress, and completion/error state.
- Android Google sign-in is prepared to use native Firebase Google authentication when `firebase/google-services.json` is supplied. This avoids the WebView `missing initial state` problem. Browser sign-in remains the web fallback.

## Required one-time Firebase setup

Native Google Sign-In cannot be fully activated from the existing web Firebase config alone. Firebase requires an Android app registration, signing certificate SHA-1 and `google-services.json`. See `firebase/README.md`.

## Not claimed

This source package has not been honestly declared device-verified for every feature. The next APK build must be installed and tested on the user's Android phone, especially native Google sign-in, notifications, JSON import/export and the two-PDF Gemini analysis pipeline.
