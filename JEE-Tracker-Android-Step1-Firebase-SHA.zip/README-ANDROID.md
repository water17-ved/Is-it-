# JEE Tracker Android — Stage 7

Stage 7 adds offline/network resilience on top of Stage 6.

## Offline behavior
- The core tracker remains local-first.
- App shell and local bridge scripts are precached by the service worker where service workers are supported.
- Gemini and OpenAI remain online-only and are never served from cache.
- Firebase remains network-only.
- A small network-status banner indicates offline/online transitions.

## Important Android note
Capacitor bundles the web assets into the Android app, so the service worker is an additional PWA/browser resilience layer, not the sole offline mechanism. Native Android behavior must still be verified on a real device.
