# JEE Tracker Android — GitHub build package

## IMPORTANT: GitHub does NOT extract ZIP files

If you are using GitHub from your phone, do **not** upload this ZIP as a single repository file and expect GitHub Actions to see `www/index.html`.

You must extract this ZIP first, then upload the **contents** to the repository root.

After extraction, the repository root must look approximately like this:

```text
.github/
  workflows/
    build-apk.yml
www/
  index.html
  schedule.html
  test-analysis.html
package.json
capacitor.config.ts
native-android/
  apply-widgets.py
firebase/
  google-services.json
```

## Phone-only upload

1. Download this ZIP.
2. Extract it with your Android file manager.
3. Open the extracted folder.
4. In GitHub, open your repository.
5. Remove the old build workflow(s) if they conflict with this one.
6. Upload the **extracted files/folders**, including the hidden `.github` folder.
7. Commit everything to `main`.
8. Open **Actions**.
9. Select **Build JEE Tracker Android APK**.
10. Run workflow.

The workflow also contains a recovery mechanism: if the repository already contains a `JEE-Tracker-Android-*.zip` but no source files, it will attempt to extract the newest archive. This is a fallback only; the recommended setup is to extract the package before uploading.

## What the workflow does

1. Checks out the repository.
2. Installs Node 22, Java 21 and Android SDK.
3. Verifies the real JEE Tracker source exists.
4. Installs Capacitor dependencies.
5. Creates the Android project.
6. Applies the JEE Tracker home-screen widgets.
7. Configures Firebase Google Sign-In when `firebase/google-services.json` exists.
8. Synchronizes Capacitor.
9. Generates the Android debug SHA-1.
10. Builds `app-debug.apk`.
11. Uploads the APK and SHA-256.
12. Uploads the Firebase SHA-1 report.

## Firebase

The included `google-services.json` is from the existing JEE Tracker Firebase project. The Android package is:

```text
com.vedplayer.jeetracker
```

After the workflow produces `firebase-debug-sha1.txt`, add that SHA-1 to Firebase. Then download the updated `google-services.json` from Firebase and replace:

```text
firebase/google-services.json
```

Commit the updated file and run the workflow again.

If Google Sign-In is not needed yet, the workflow can also build without the Firebase file.

## Gemini

Do NOT put your Gemini API key in GitHub. Enter it through the app's AI/Gemini settings after installation.

## Expected artifacts

Successful run:

- `jee-tracker-debug-apk`
  - `app-debug.apk`
  - `app-debug.apk.sha256`
- `jee-tracker-firebase-debug-sha1`
  - `firebase-debug-sha1.txt`
  - `signing-report.txt`

## Important

A ZIP stored inside a GitHub repository is just a ZIP file. GitHub Actions cannot run files that are still inside that ZIP unless the workflow explicitly extracts it. This package therefore includes both the complete source tree and a fallback archive-extraction step.
